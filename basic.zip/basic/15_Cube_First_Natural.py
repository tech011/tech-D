n = int(input("Enter n: "))
sum_cubes = ((n * (n + 1)) // 2) ** 2
print("Sum of cubes:", sum_cubes)
