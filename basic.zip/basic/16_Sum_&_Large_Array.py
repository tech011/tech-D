arr = list(map(int, input("Enter array elements separated by space: ").split()))
print("Sum of array:", sum(arr))


arr = list(map(int, input("Enter array elements separated by space: ").split()))
print("Largest element:", max(arr))
