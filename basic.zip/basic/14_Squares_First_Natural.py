n = int(input("Enter n: "))
sum_ = (n * (n + 1) * (2 * n + 1)) // 6
print("Sum of squares =", sum_)
